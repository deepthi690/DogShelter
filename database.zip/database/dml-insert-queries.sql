use mydb;
INSERT INTO Shelter (shelter_ID, name, phone, email, address) VALUES
(101, 'Sunnydale Shelter', '555-1234', 'info@sunnydale.com', '1234 Sunny St, Sunnydale, CA'),
(102, 'Rivertown Rescue', '555-5678', 'contact@rivertownrescue.com', '45 River Rd, Rivertown, MA'),
(103, 'Hillside Haven', '555-8765', 'support@hillsidehaven.org', '789 Hill St, Hilltown, TX'),
(104, 'Lakeside Animal Center', '555-4321', 'lakeside@lacenter.org', '321 Lake Ave, Laketown, FL'),
(105, 'Greenfield Shelter', '555-6789', 'info@greenfieldshelter.org', '567 Green St, Greenfield, NY'),
(106, 'Northridge Animal Home', '555-9876', 'care@northridgehome.org', '234 North St, Northridge, VA'),
(107, 'Eastside Kennels', '555-6543', 'hello@eastsidekennels.com', '890 East Rd, Eastville, IL'),
(108, 'Westwood Pets', '555-3214', 'contact@westwoodpets.com', '654 West St, Westwood, CA'),
(109, 'Southgate Animal Clinic', '555-2134', 'clinic@southgate.com', '321 South Ave, Southgate, NJ'),
(110, 'Midtown Pet Care', '555-1923', 'info@midtownpetcare.org', '987 Center St, Midtown, CO');
INSERT INTO Health_Record (record_ID, dog_ID, date, description) VALUES
(1001, 1, '2023-01-01', 'Annual vaccination and wellness check.'),
(1002, 2, '2023-01-02', 'Treated for fleas and tick prevention.'),
(1003, 3, '2023-01-03', 'Neutering surgery and post-op care.'),
(1004, 4, '2023-01-04', 'Dental cleaning and oral health check.'),
(1005, 5, '2023-01-05', 'Treated for minor skin infection.'),
(1006, 6, '2023-01-06', 'Heartworm preventative administered.'),
(1007, 7, '2023-01-07', 'Microchip implantation.'),
(1008, 8, '2023-01-08', 'Received rabies vaccine.'),
(1009, 9, '2023-01-09', 'Allergy assessment and treatment.'),
(1010, 10, '2023-01-10', 'Routine checkup and weight management.');
INSERT INTO Dog (dog_ID, dog_name, breed, gender, age, shelter_ID, record_ID) VALUES
(1, 'Buddy', 'Golden Retriever', 'M', 3, 101, 1001),
(2, 'Lucy', 'Beagle', 'F', 4, 102, 1002),
(3, 'Charlie', 'Poodle', 'M', 2, 103, 1003),
(4, 'Daisy', 'Shih Tzu', 'F', 5, 101, 1004),
(5, 'Max', 'Bulldog', 'M', 6, 102, 1005),
(6, 'Bella', 'Chihuahua', 'F', 1, 103, 1006),
(7, 'Rocky', 'Boxer', 'M', 4, 101, 1007),
(8, 'Maggie', 'Dachshund', 'F', 2, 102, 1008),
(9, 'Jake', 'Pit Bull', 'M', 7, 103, 1009),
(10, 'Molly', 'Labrador', 'F', 5, 101, 1010);

INSERT INTO Manager (manager_ID, shelter_ID) VALUES
(301, 101),
(302, 102),
(303, 103),
(304, 104),
(305, 105),
(306, 106),
(307, 107),
(308, 108),
(309, 109),
(310, 110);
INSERT INTO Employee (employee_ID, fullname, phone, address, email, manager_ID) VALUES
(201, 'Jane Doe', '555-5678', '12 Elm St, Sunnydale, CA', 'jane.doe@example.com', 301),
(202, 'Max Brown', '555-3456', '34 Oak St, Rivertown, MA', 'max.brown@example.com', 302),
(203, 'Emily White', '555-9870', '56 Pine St, Hilltown, TX', 'emily.white@example.com', 303),
(204, 'Chris Green', '555-2345', '78 Birch Ave, Laketown, FL', 'chris.green@example.com', 304),
(205, 'Alex Johnson', '555-8765', '98 Maple Rd, Greenfield, NY', 'alex.johnson@example.com', 305),
(206, 'Sarah Miller', '555-6543', '12 Spruce Way, Northridge, VA', 'sarah.miller@example.com', 306),
(207, 'David Wilson', '555-1234', '23 Cedar Ln, Eastville, IL', 'david.wilson@example.com', 307),
(208, 'Jessica Lee', '555-4321', '45 Willow Dr, Westwood, CA', 'jessica.lee@example.com', 308),
(209, 'Michael Taylor', '555-3214', '67 Elm St, Southgate, NJ', 'michael.taylor@example.com', 309),
(210, 'Laura Anderson', '555-6789', '89 Oak Blvd, Midtown, CO', 'laura.anderson@example.com', 310);
INSERT INTO Volunteer (volunteer_ID, fullname, email, phone, start_date) VALUES
(401, 'John Smith', 'john.smith@example.com', '555-7890', '2022-01-10'),
(402, 'Lisa Ray', 'lisa.ray@example.com', '555-5643', '2022-02-15'),
(403, 'Omar Khan', 'omar.khan@example.com', '555-9812', '2022-03-20'),
(404, 'Angela Martinez', 'angela.martinez@example.com', '555-2321', '2022-04-25'),
(405, 'Trevor Noah', 'trevor.noah@example.com', '555-6874', '2022-05-30'),
(406, 'Karen White', 'karen.white@example.com', '555-4789', '2022-06-04'),
(407, 'Raj Patel', 'raj.patel@example.com', '555-7894', '2022-07-09'),
(408, 'Samantha Bloom', 'samantha.bloom@example.com', '555-3456', '2022-08-14'),
(409, 'Michael Lee', 'michael.lee@example.com', '555-6548', '2022-09-19'),
(410, 'Chloe Tan', 'chloe.tan@example.com', '555-2135', '2022-10-24');
INSERT INTO Volunteering (volunteer_ID, shelter_ID) VALUES
(401, 101),
(402, 102),
(403, 103),
(404, 104),
(405, 105),
(406, 106),
(407, 107),
(408, 108),
(409, 109),
(410, 110);
INSERT INTO Adopter (adopter_ID, fullname, phone, email, address) VALUES
(501, 'Alice Johnson', '555-1239', 'alice.j@example.com', '2345 Maple St, Sunnydale, CA'),
(502, 'Greg Brown', '555-1240', 'greg.b@example.com', '4567 Pine St, Rivertown, MA'),
(503, 'Maria Garcia', '555-1241', 'maria.g@example.com', '7890 Birch Rd, Hilltown, TX'),
(504, 'David Wilson', '555-1242', 'david.w@example.com', '1234 Cedar Ave, Laketown, FL'),
(505, 'Sophia Lee', '555-1243', 'sophia.l@example.com', '5678 Spruce Way, Greenfield, NY'),
(506, 'Michael Miller', '555-1244', 'michael.m@example.com', '9012 Oak Blvd, Northridge, VA'),
(507, 'Chloe Kim', '555-1245', 'chloe.k@example.com', '3456 Elm Lane, Eastville, IL'),
(508, 'Lucas Morgan', '555-1246', 'lucas.m@example.com', '7890 Willow Dr, Westwood, CA'),
(509, 'Emma White', '555-1247', 'emma.w@example.com', '1234 Maple Rd, Southgate, NJ'),
(510, 'James Lee', '555-1248', 'james.l@example.com', '5678 Oak St, Midtown, CO');
INSERT INTO Adoptee (adoptee_ID, dog_ID, adopter_ID, adoption_date) VALUES
(601, 1, 501, '2023-02-01'),
(602, 2, 502, '2023-02-02'),
(603, 3, 503, '2023-02-03'),
(604, 4, 504, '2023-02-04'),
(605, 5, 505, '2023-02-05'),
(606, 6, 506, '2023-02-06'),
(607, 7, 507, '2023-02-07'),
(608, 8, 508, '2023-02-08'),
(609, 9, 509, '2023-02-09'),
(610, 10, 510, '2023-02-10');
INSERT INTO Application (application_ID, dog_ID, adopter_ID, application_date) VALUES
(701, 1, 501, '2023-01-15'),
(702, 2, 502, '2023-01-16'),
(703, 3, 503, '2023-01-17'),
(704, 4, 504, '2023-01-18'),
(705, 5, 505, '2023-01-19'),
(706, 6, 506, '2023-01-20'),
(707, 7, 507, '2023-01-21'),
(708, 8, 508, '2023-01-22'),
(709, 9, 509, '2023-01-23'),
(710, 10, 510, '2023-01-24');
INSERT INTO Event (event_ID, event_name, event_description, volunteer_ID, shelter_ID) VALUES
(801, 'Adoption Day', 'A special day to promote dog adoptions at the shelter.', 401, 101),
(802, 'Pet Care Workshop', 'Learn how to take care of your pets, focusing on health and nutrition.', 402, 102),
(803, 'Holiday Fundraiser', 'Raising funds for shelter operations through holiday-themed activities.', 403, 103),
(804, 'Volunteer Orientation', 'Orientation day for new volunteers joining the shelter.', 404, 104),
(805, 'Senior Dog Month', 'Promotion and awareness campaign for adopting older dogs.', 405, 105),
(806, 'Spay and Neuter Clinic', 'Providing low-cost spay and neuter services to the community.', 406, 106),
(807, 'Microchip Clinic', 'A day dedicated to microchipping pets to ensure their safety.', 407, 107),
(808, 'Summer Pet Fest', 'A festival celebrating pets with games, adoptions, and food.', 408, 108),
(809, 'Dog Training Sessions', 'Professional dog trainers teach basic obedience and tricks.', 409, 109),
(810, 'Foster Care Info Session', 'Information session on how to become a foster parent for pets.', 410, 110);
INSERT INTO Feedback (feedback_ID, adopter_ID, rating, review, date) VALUES
(901, 501, 5, 'Extremely happy with the adoption process, very well managed!', '2023-02-15'),
(902, 502, 4, 'Good experience, but I wish there were more staff available during visiting hours.', '2023-02-16'),
(903, 503, 5, 'Loved the caring nature of the staff, very supportive during the adoption!', '2023-02-17'),
(904, 504, 3, 'The process was a bit slow, but I got a wonderful new friend!', '2023-02-18'),
(905, 505, 5, 'Very professional and helpful, answered all my questions.', '2023-02-19'),
(906, 506, 4, 'Great shelter, only issue was the parking was a bit limited.', '2023-02-20'),
(907, 507, 5, 'Fantastic experience, very thorough with their pet care advice.', '2023-02-21'),
(908, 508, 2, 'The facility was a bit crowded, and it seemed understaffed.', '2023-02-22'),
(909, 509, 5, 'Super friendly staff and very clean environment. Highly recommend!', '2023-02-23'),
(910, 510, 4, 'Good overall, but the initial paperwork took longer than expected.', '2023-02-24');
INSERT INTO Trainer (trainer_ID, fullname, phone, email, speciality) VALUES
(1001, 'Bob White', '555-3456', 'bob.white@example.com', 'Obedience training'),
(1002, 'Sara Knight', '555-6543', 'sara.knight@example.com', 'Behavioral training'),
(1003, 'Jason Lee', '555-9876', 'jason.lee@example.com', 'Agility training'),
(1004, 'Emily Clark', '555-2134', 'emily.clark@example.com', 'Therapy dog training'),
(1005, 'David Smith', '555-8765', 'david.smith@example.com', 'Puppy training'),
(1006, 'Angela Martin', '555-4321', 'angela.martin@example.com', 'Rescue dog rehabilitation'),
(1007, 'Mark Johnson', '555-1239', 'mark.johnson@example.com', 'Advanced obedience'),
(1008, 'Rachel Green', '555-1240', 'rachel.green@example.com', 'Trick training'),
(1009, 'Kevin Brown', '555-1241', 'kevin.brown@example.com', 'Service dog training'),
(1010, 'Laura Wilson', '555-1242', 'laura.wilson@example.com', 'Search and rescue training');
INSERT INTO Training_Session (session_ID, trainer_ID, dog_ID, date, time, notes) VALUES
(1101, 1001, 1, '2023-03-01', '10:00:00', 'Initial obedience training session, focus on sit and stay commands.'),
(1102, 1002, 2, '2023-03-02', '11:00:00', 'Behavioral correction for aggression towards other dogs.'),
(1103, 1003, 3, '2023-03-03', '12:00:00', 'Agility training focusing on course completion.'),
(1104, 1004, 4, '2023-03-04', '13:00:00', 'Training for therapy dog certification.'),
(1105, 1005, 5, '2023-03-05', '14:00:00', 'Puppy socialization and basic commands.'),
(1106, 1006, 6, '2023-03-06', '15:00:00', 'Rehabilitation training for rescue dog with anxiety.'),
(1107, 1007, 7, '2023-03-07', '16:00:00', 'Advanced obedience training, including heel and come.'),
(1108, 1008, 8, '2023-03-08', '17:00:00', 'Fun trick training session, learning how to roll over.'),
(1109, 1009, 9, '2023-03-09', '18:00:00', 'Service dog training, focus on item retrieval.'),
(1110, 1010, 10, '2023-03-10', '09:00:00', 'Search and rescue training, scent tracking exercises.');
INSERT INTO Maintenance (request_ID, shelter_ID, description, date) VALUES
(1201, 101, 'Repair broken fence in the dog play area.', '2023-03-15'),
(1202, 102, 'Fix leaking roof in the storage shed.', '2023-03-16'),
(1203, 103, 'Update HVAC system for better temperature control.', '2023-03-17'),
(1204, 104, 'Replace old kennels with new models.', '2023-03-18'),
(1205, 105, 'Electrical check and fixture replacement in main office.', '2023-03-19'),
(1206, 106, 'Plumbing repair in the grooming area.', '2023-03-20'),
(1207, 107, 'Install new security cameras around the property.', '2023-03-21'),
(1208, 108, 'Landscape the front entrance to improve curb appeal.', '2023-03-22'),
(1209, 109, 'Repair and repaint the community meeting room.', '2023-03-23'),
(1210, 110, 'General maintenance and cleaning of all facilities.', '2023-03-24');

