CREATE TABLE Shelter (
    shelter_ID INT PRIMARY KEY,
    name VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(100),
    address VARCHAR(255)
);
CREATE TABLE Health_Record (
    record_ID INT PRIMARY KEY,
    dog_ID INT,
    date DATE,
    description TEXT
);
CREATE TABLE Dog (
    dog_ID INT PRIMARY KEY,
    dog_name VARCHAR(255),
    breed VARCHAR(255),
    gender CHAR(1),
    age INT,
    shelter_ID INT,
    record_ID INT,
    FOREIGN KEY (shelter_ID) REFERENCES Shelter(shelter_ID),
    FOREIGN KEY (record_ID) REFERENCES Health_Record(record_ID)
);

CREATE TABLE Manager (
    manager_ID INT PRIMARY KEY,
    shelter_ID INT,
    FOREIGN KEY (shelter_ID) REFERENCES Shelter(shelter_ID)
);
CREATE TABLE Employee (
    employee_ID INT PRIMARY KEY,
    fullname VARCHAR(255),
    phone VARCHAR(20),
    address VARCHAR(255),
    email VARCHAR(100),
    manager_ID INT,
    FOREIGN KEY (manager_ID) REFERENCES Manager(manager_ID)
);
CREATE TABLE Volunteer (
    volunteer_ID INT PRIMARY KEY,
    fullname VARCHAR(255),
    email VARCHAR(100),
    phone VARCHAR(20),
    start_date DATE
);
CREATE TABLE Volunteering (
    volunteer_ID INT,
    shelter_ID INT,
    PRIMARY KEY (volunteer_ID, shelter_ID),
    FOREIGN KEY (volunteer_ID) REFERENCES Volunteer(volunteer_ID),
    FOREIGN KEY (shelter_ID) REFERENCES Shelter(shelter_ID)
);
CREATE TABLE Adopter (
    adopter_ID INT PRIMARY KEY,
    fullname VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(100),
    address VARCHAR(255)
);
CREATE TABLE Adoptee (
    adoptee_ID INT PRIMARY KEY,
    dog_ID INT,
    adopter_ID INT,
    adoption_date DATE,
    FOREIGN KEY (dog_ID) REFERENCES Dog(dog_ID),
    FOREIGN KEY (adopter_ID) REFERENCES Adopter(adopter_ID)
);
CREATE TABLE Application (
    application_ID INT PRIMARY KEY,
    dog_ID INT,
    adopter_ID INT,
    application_date DATE,
    FOREIGN KEY (dog_ID) REFERENCES Dog(dog_ID),
    FOREIGN KEY (adopter_ID) REFERENCES Adopter(adopter_ID)
);
CREATE TABLE Event (
    event_ID INT PRIMARY KEY,
    event_name VARCHAR(255),
    event_description TEXT,
    volunteer_ID INT,
    shelter_ID INT,
    FOREIGN KEY (volunteer_ID) REFERENCES Volunteer(volunteer_ID),
    FOREIGN KEY (shelter_ID) REFERENCES Shelter(shelter_ID)
);
CREATE TABLE Feedback (
    feedback_ID INT PRIMARY KEY,
    adopter_ID INT,
    rating INT,
    review TEXT,
    date DATE,
    FOREIGN KEY (adopter_ID) REFERENCES Adopter(adopter_ID)
);
CREATE TABLE Trainer (
    trainer_ID INT PRIMARY KEY,
    fullname VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(100),
    speciality VARCHAR(255)
);
CREATE TABLE Training_Session (
    session_ID INT PRIMARY KEY,
    trainer_ID INT,
    dog_ID INT,
    date DATE,
    time TIME,
    notes TEXT,
    FOREIGN KEY (trainer_ID) REFERENCES Trainer(trainer_ID),
    FOREIGN KEY (dog_ID) REFERENCES Dog(dog_ID)
);
CREATE TABLE Maintenance (
    request_ID INT PRIMARY KEY,
    shelter_ID INT,
    description TEXT,
    date DATE,
    FOREIGN KEY (shelter_ID) REFERENCES Shelter(shelter_ID)
);
